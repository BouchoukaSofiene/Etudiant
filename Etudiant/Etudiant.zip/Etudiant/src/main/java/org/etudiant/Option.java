package org.etudiant;

public interface Option {
    double calculerScore(Etudiant etudiant);
}
